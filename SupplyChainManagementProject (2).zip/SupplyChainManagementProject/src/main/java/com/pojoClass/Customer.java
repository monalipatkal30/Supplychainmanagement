package com.pojoClass;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Customers")
public class Customer {

    @Id
    @SequenceGenerator(name = "customer_seq", sequenceName = "customer_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_seq")
    private Long customerId;
    
    @Column(length = 30, nullable = false)
    private String orgName;
    
    @Column(length = 20, nullable = false)
    private String contactPerson;
    
    @Column(length = 20, unique = true, nullable = false)
    private String contactNumber;
    
    @Column(length = 50, unique = true, nullable = false)
    private String email;
    

    @Column(length = 30, unique = true, nullable = false)
    private String userName;
    
    @Column(length = 30, nullable = false)
    private String password;

	// Getters and Setters
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", orgName=" + orgName + ", contactPerson=" + contactPerson
				+ ", contactNumber=" + contactNumber + ", email=" + email + ", userName=" + userName + ", password="
				+ password + "]";
	}
}
