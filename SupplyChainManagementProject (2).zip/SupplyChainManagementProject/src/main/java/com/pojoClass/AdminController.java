package com.pojoClass;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminRepository adminRepo;

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpServletRequest request) {
        int isValid = adminRepo.validateAdmin(username, password);

        if (isValid > 0) {
            // ✅ Successful login: redirect to welcome.jsp
            return "welcome";
        } else {
            // ❌ Invalid login: show error on login page
            request.setAttribute("error", "admin");
            return "loginPage";
        }
    }

}


