package com.pojoClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository; //repository to interact with database

	public void saveCustomer(Customer customer) {
		customerRepository.save(customer); // saving customer in database
	}

}
