package com.pojoClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/dealers")
public class DealerController {

	@Autowired
	private DealerService dealerService;
	
	@Autowired
	private DealerRepository dealerRepository;
	
	@GetMapping("/registerDealer")
	public String showRegistrationForm() {
		return "dealerRegistration";
	}
	
	@PostMapping("registerDealer")
	public String registerDealer(@ModelAttribute Dealer dealer) {
		System.out.println("Dealer Regitered: " + dealer);
		dealerService.saveDealer(dealer);
		return "welcome";
	}
	
	
	//login controller for dealer
	
	@PostMapping("/login")
	public String login(@RequestParam String username,
						@RequestParam String password,
						HttpServletRequest request) {
		int isValid = dealerRepository.validateDealer(username, password);
		
		if (isValid > 0) {
			return "welcome";
		} else {
			request.setAttribute("error", "dealer");
			return "loginPage";
		}
	}
	
}
