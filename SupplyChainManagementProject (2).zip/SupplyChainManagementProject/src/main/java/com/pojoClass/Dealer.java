package com.pojoClass;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Dealers")
public class Dealer {


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dealer_seq")
    @SequenceGenerator(name = "dealer_seq", sequenceName = "dealer_seq", allocationSize = 1)
    private Long dealerId;
    
    @Column(length = 30, nullable = false)
    private String orgName;
    
    @Column(length = 20, nullable = false)
    private String contactPerson;
    
    @Column(length = 20, unique = true, nullable = false)
    private String contactNumber;
    
    @Column(length = 50, unique = true, nullable = false)
    private String offEmail;
    
    @Column(length = 60, nullable = false)
    private String addrWarehouse;
    
    @Column(length = 60, nullable = false)
    private String addrRegOffice;
    
    @Column(length = 30, nullable = false, unique = true)
    private String userName;
    
    @Column(length = 30, nullable = false, unique = true)
    private String password;
    

	public Long getDealerId() {
		return dealerId;
	}

	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getOffEmail() {
		return offEmail;
	}

	public void setOffEmail(String offEmail) {
		this.offEmail = offEmail;
	}

	public String getAddrWarehouse() {
		return addrWarehouse;
	}

	public void setAddrWarehouse(String addrWarehouse) {
		this.addrWarehouse = addrWarehouse;
	}

	public String getAddrRegOffice() {
		return addrRegOffice;
	}

	public void setAddrRegOffice(String addrRegOffice) {
		this.addrRegOffice = addrRegOffice;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Dealer [dealerId=" + dealerId + ", orgName=" + orgName + ", contactPerson=" + contactPerson
				+ ", contactNumber=" + contactNumber + ", offEmail=" + offEmail + ", addrWarehouse=" + addrWarehouse
				+ ", addrRegOffice=" + addrRegOffice + ", userName=" + userName + ", password=" + password + "]";
	}
	
	
    
    
}
