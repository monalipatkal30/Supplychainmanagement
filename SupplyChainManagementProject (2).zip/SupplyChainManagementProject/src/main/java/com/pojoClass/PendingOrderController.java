package com.pojoClass;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PendingOrderController {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@GetMapping("/getData")
	public ModelAndView getDataDealer() {
		ModelAndView mv = new ModelAndView();
		List<Product> productList= productRepository.findAll();
		for (Product product : productList) {
			System.out.println(product);
		}
		//prodN, q, da
		List<Customer> customersList= customerRepository.findAll();
		//customerName
		for (Customer customer : customersList) {
			System.out.println(customer);
		}
		mv.setViewName("pendingOrdersForDealers");
		mv.addObject("p1", productList);
		mv.addObject("c1", customersList);
		return mv;
	}
	

	@GetMapping("/getData2")
	public ModelAndView getDataAdmin() {
		ModelAndView mv = new ModelAndView();
		List<Product> productList= productRepository.findAll();
		for (Product product : productList) {
			System.out.println(product);
		}
		//prodN, q, da
		List<Customer> customersList= customerRepository.findAll();
		//customerName
		for (Customer customer : customersList) {
			System.out.println(customer);
		}
		mv.setViewName("pendingOrdersForAdmin");
		mv.addObject("p1", productList);
		mv.addObject("c1", customersList);
		return mv;
	}
	

	@GetMapping("/getData3")
	public ModelAndView trackOrderDealer() {
		ModelAndView mv = new ModelAndView();
		List<Product> productList= productRepository.findAll();
		for (Product product : productList) {
			System.out.println(product);
		}
		//prodN, q, da
		List<Customer> customersList= customerRepository.findAll();
		//customerName
		for (Customer customer : customersList) {
			System.out.println(customer);
		}
		mv.setViewName("trackOrderDealer");
		mv.addObject("p1", productList);
		mv.addObject("c1", customersList);
		return mv;
	}
	
	
	
	
}
