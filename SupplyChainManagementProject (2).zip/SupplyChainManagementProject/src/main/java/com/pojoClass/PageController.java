package com.pojoClass;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/dealerRegistration")
    public String dealerRegistrationPage() {
        return "dealerRegistration"; // Will map to /WEB-INF/view/dealerRegistration.jsp
    }

    @GetMapping("/customerRegistration")
    public String customerRegistrationPage() {
        return "customerRegistration";
    }

    @GetMapping("/placeOrder")
    public String placeOrderPage() {
        return "placeOrder";
    }

    @GetMapping("/pendingOrdersForDealers")
    public String pendingOrdersDealerPage() {
        return "pendingOrdersForDealers";
    }

    @GetMapping("/pendingOrdersForAdmin")
    public String pendingOrdersAdminPage() {
        return "pendingOrdersForAdmin";
    }

    @GetMapping("/trackOrderDealer")
    public String trackOrderDealerPage() {
        return "trackOrderDealer";
    }

    @GetMapping("/loginPage")
    public String loginPage() {
        return "loginPage";
    }
}

