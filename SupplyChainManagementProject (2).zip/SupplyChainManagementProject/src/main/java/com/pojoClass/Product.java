package com.pojoClass;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Orders_Placed")
public class Product {

	@Id
	@SequenceGenerator(name = "product_seq", sequenceName = "product_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq")
	private int id;

	@Column(length = 20, nullable = false)
	private String prodId;
	
	@Column(length = 50, nullable = false)
	private String prodName;
	
	@Column(length = 20, nullable = false)
	private Integer quantity;
	
	@Column(length = 60, nullable = false)
	private String deliveryAddr;

	public String getProdId() {
		return prodId;
	}

	public void setProdId(String prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getDeliveryAddr() {
		return deliveryAddr;
	}

	public void setDeliveryAddr(String deliveryAddr) {
		this.deliveryAddr = deliveryAddr;
	}

	@Override
	public String toString() {
		return "Orders [prodId=" + prodId + ", prodName=" + prodName + ", quantity=" + quantity + ", deliveryAddr="
				+ deliveryAddr + "]";
	}

	
	
	
}
