package com.pojoClass;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerRepository customerRepository;
	
	@Autowired
	private CustomerService customerService;


    CustomerController(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }
	

		
	/*
	 * @GetMapping("/registerCustomer") public String
	 * registerCustomer(HttpServletRequest request) { Customer customer = new
	 * Customer(); customer.setOrgName(request.getParameter("orgName"));
	 * customer.setContactPerson(request.getParameter("contactPerson"));
	 * customer.setContactNumber(request.getParameter("contactNumber"));
	 * customer.setEmail(request.getParameter("email")); repo.save(customer); return
	 * "welcome.jsp"; }
	 * 
	 * @PostMapping("/registerCustomer1")
	 * 
	 * @ResponseBody public Customer registerCustomer1(@RequestBody Customer
	 * customer) {
	 * 
	 * repo.save(customer); System.out.println("hello from customer controller");
	 * return customer; }
	 */
	
	
	// GET request to show registration form
	@GetMapping("/registerCustomer")
	public String showRegistrationForm() {
		return "customerRegistration";
	}
	
	//POST request to submit the form
	@PostMapping("/registerCustomer")
	public String registerCustomer(@ModelAttribute Customer customer) {
		System.out.println("Customer Registered: " + customer);
		customerService.saveCustomer(customer); //saving the customer in database
		return "welcome"; // Returning the jsp page after successful registration
	}
	
	
	//For login controller of customer
	
	@PostMapping("/login")
	public String login(@RequestParam String username,
						@RequestParam String password,
						HttpServletRequest request) {
		int isValid = customerRepository.validateCustomer(username, password);
		
		if (isValid > 0) {
			return "welcome";
		} else {
			request.setAttribute("error", "customer");
			return "loginPage";
		}
	}
	
	
	
	
}
	

