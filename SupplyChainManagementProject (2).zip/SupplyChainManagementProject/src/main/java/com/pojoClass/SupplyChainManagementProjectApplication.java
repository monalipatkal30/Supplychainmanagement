package com.pojoClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

@SpringBootApplication
//@EntityScan("com.pojoClass")
//@ComponentScan(basePackages = {"com.pojoClass","com.main" })
public class SupplyChainManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplyChainManagementProjectApplication.class, args);
		System.out.println("Hello from spring");
	}

}
